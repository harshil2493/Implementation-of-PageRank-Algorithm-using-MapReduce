package cs535.hw1;

public enum CountMe {
	countOfLinks
}
