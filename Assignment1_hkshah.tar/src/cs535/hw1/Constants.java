package cs535.hw1;

public class Constants {
	public static String phase1TitleConstant = "##TITLE##";
	
	public static String phase1RedirectConstant = "##REDIRECT##";
	
	public static String titleLink = "&!&";
	
	public static String linkLink = "!:!";
	
	public static String linkToOccurance = "@~+";
	
	public static String titleToRank = "%&!";
	
	public static String titleToIterate = "@&%";

	public static String valueSeparator = ":!@";

	public static String idealized = "##IDEALIZED##";
	
	public static String taxation = "##TAXATION##";

	public static String difference = "##DIFF##";
}
